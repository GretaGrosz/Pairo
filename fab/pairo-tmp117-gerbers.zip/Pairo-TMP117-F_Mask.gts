%TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*%
%TF.CreationDate,2026-11-16T18:11:00+01:00*%
%TF.ProjectId,Pairo-TMP117,50616972-6f2d-4544-9d50-3131372e6b69,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-16 18:11:00*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.225000X0.250000X-0.225000X0.250000X0.225000X-0.250000X0.225000X-0.250000X-0.225000X0*%
%ADD11R,0.600000X1.550000*%
%ADD12R,1.200000X1.800000*%
%ADD13O,0.607000X0.364000*%
%ADD14R,1.000000X1.600000*%
G04 APERTURE END LIST*
D10*
%TO.C,C1*%
X103900000Y-85075000D03*
X103900000Y-83525000D03*
%TD*%
D11*
%TO.C,CN1*%
X105500000Y-86960000D03*
X106500000Y-86960000D03*
X107500000Y-86960000D03*
X108500000Y-86960000D03*
D12*
X109800000Y-90840000D03*
X104200000Y-90840000D03*
%TD*%
D13*
%TO.C,U1*%
X108030000Y-84250000D03*
X108030000Y-83600000D03*
X108030000Y-82950000D03*
X105970000Y-82950000D03*
X105970000Y-83600000D03*
X105970000Y-84250000D03*
D14*
X107000000Y-83600000D03*
%TD*%
M02*
